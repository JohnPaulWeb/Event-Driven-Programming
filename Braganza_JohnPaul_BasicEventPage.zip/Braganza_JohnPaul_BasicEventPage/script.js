

const pageContainer = document.querySelector("#pageContainer");
const heading = document.querySelector("#mainHeading");
const nameInput = document.querySelector("#nameInput");
const greetingButton = document.querySelector("#greetingButton");
const backgroundButton = document.querySelector("#backgroundButton");
const resetButton = document.querySelector("#resetButton");
const messageArea = document.querySelector("#messageArea");


const typingMessage = document.querySelector("#typingMessage");


const originalHeading = "Event-Driven Webpage";
const originalBackground = "#f3f4f6";



function displayGreeting() {
    const userName = nameInput.value.trim();

    if (userName === "") {
        messageArea.textContent = "Please enter your name.";
        console.log("Greeting button clicked, but no name was entered.");
    } else {
        heading.innerHTML =
            "Semester: 1st Academic Year: 2026-2027<br>" +
            "Hello, " + userName + "!";

        messageArea.textContent =
            "The greeting was displayed successfully.";

        console.log("Greeting displayed for: " + userName);
    }
}




function showTypedText() {
    typingMessage.textContent =
        "You are typing: " + nameInput.value;

    console.log("User is typing: " + nameInput.value);
}




function changeBackground() {
    document.body.style.backgroundColor = "lightblue";

    messageArea.textContent =
        "The background color has been changed.";

    console.log("Background color changed.");
}




function resetPage() {
    heading.textContent = originalHeading;

    nameInput.value = "";

    typingMessage.textContent = "You are typing:";

    messageArea.textContent =
        "Enter your name and select an action.";

    document.body.style.backgroundColor = originalBackground;

    console.log("Page has been reset.");
}




function handleMouseOver(event) {
    console.log(
        "The mouse is over the " +
        event.target.textContent.trim() +
        "."
    );
}




greetingButton.addEventListener("click", displayGreeting);


backgroundButton.addEventListener("click", changeBackground);


resetButton.addEventListener("click", resetPage);


nameInput.addEventListener("input", showTypedText);


greetingButton.addEventListener("mouseover", handleMouseOver);
backgroundButton.addEventListener("mouseover", handleMouseOver);
resetButton.addEventListener("mouseover", handleMouseOver);


console.log("JavaScript file loaded successfully.");
